package day2;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;


public class Webelement {

public static void main(String[] args) {
System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

		
		
		WebDriver driver=new ChromeDriver();

		driver.get("https://www.snapdeal.com");
		driver.get("https://www.amazon.in");
		
//		driver.navigate().back();
//		driver.navigate().forward();
//		WebElement searchstore=driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
		
		
//		isDisplayed isenabled
		
		
//		System.out.println("Display status:"+searchstore.isDisplayed());
//		System.out.println("Enabled status:"+searchstore.isEnabled());

	}

}
