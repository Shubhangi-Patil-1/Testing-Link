package day2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Navigation_command {
public static void main(String[] args) {
		
	System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");
		
	WebDriver driver=new ChromeDriver();
		
		driver.navigate().to("https://www.edubridgeindia.com");
		
		String log = "https://www.edubridgeindia.com/login";
		
		driver.get(log);
				
		driver.get("https://www.amazon.in/Books-Login/s?rh=n%3A976389031%2Cp_27%3ALogin");
		
		driver.navigate().back();
		
		driver.navigate().forward();
		
		driver.navigate().to(log);
		
		driver.navigate().refresh();
		
		driver.close();
		

	}

}


