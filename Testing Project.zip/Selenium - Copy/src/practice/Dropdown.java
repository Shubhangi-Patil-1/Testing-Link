package practice;



import java.util.List;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.WebElement;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.support.ui.Select;

	public class Dropdown {

		public static void main(String[] args) {
			
			
			WebDriver driver=new ChromeDriver();

			driver.get("https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C589460569870%7Cb%7Cfb%20create%20account%7C&placement=&creative=589460569870&keyword=fb%20create%20account&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696221432%26matchtype%3Db%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-332264388364%26loc_physical_ms%3D1007786%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=Cj0KCQiA14WdBhD8ARIsANao07gCwXFda4ohrrPZF6UHfiSK6C_zOeWVyC3DwkA7VfLvWh0x05IQeGoaAoy6EALw_wcB");
			
			Select se = new Select(driver.findElement(By.xpath("//*[@id=\"day\"]")));
			se.selectByValue("2");
			
			Select se1 = new Select(driver.findElement(By.xpath("//*[@id=\"month\"]")));
			se1.selectByVisibleText("March");
			
			//Select se2 = new Select(driver.findElement(By.xpath("//*[@id=\"year\"]")));
			//se2.selectByValue("2021");
			
			Select select = new Select(driver.findElement(By.xpath("//*[@id=\"year\"]")));
			select.selectByIndex(24);
			
			List<WebElement> list = se.getOptions();
			System.out.println("The dropdown options are:");
			for(WebElement opt: list)
				System.out.println(opt.getText());
			
			List<WebElement> list1 =se1.getOptions(); 
			System.out.println("The dropdown month:");
			for(WebElement opt2: list1)
				System.out.println(opt2.getText());

			
			
		}

	}

