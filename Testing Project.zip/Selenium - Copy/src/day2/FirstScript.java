package day2;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class FirstScript {
	
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

		WebDriver driver=new ChromeDriver(); //Parent p=new Child (webdriver is Parent & ChromeDriver is Child)
		
		driver.get("https://www.amazon.in/");
							
		driver.manage().window().maximize();
		String title1 = driver.getTitle();
		String url1=driver.getCurrentUrl();
		
		System.out.println("The title of the page is:" +title1);
		
		System.out.println("The title of the page is:" +url1);
		
		
		//driver.findElement(By.id("twotabsearchtextbox")).clear();
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("women kurti cloths");
		driver.findElement(By.id("nav-search-submit-button")).click();
	
		//Thread.sleep(2000);

		driver.navigate().to("google.com");
	
		driver.manage().window().maximize();
		
		
		driver.navigate().back();
		//Thread.sleep(100);
		driver.navigate().refresh();
		//driver.navigate().forward();
	    driver.quit(); //closing browser
		
		
	}

}


