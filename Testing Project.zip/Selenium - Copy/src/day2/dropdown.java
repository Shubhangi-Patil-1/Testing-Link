package day2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;



public class dropdown {
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\Desktop\\Testing\\chromedriver_win32(1)\\chromedriver.exe");

//		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		
		
		driver.get("https://www.facebook.com/signup");
		driver.manage().window().maximize();
		Select se = new Select(driver.findElement(By.xpath("//*[@id=\"day\"]")));
		se.selectByValue("2");
		
		Select ae = new Select(driver.findElement(By.xpath("//*[@id=\"month\"]")));
		ae.selectByValue("March");
		
		Select be = new Select(driver.findElement(By.xpath("//*[@id=\"year\"]")));
		be.selectByValue("1998");
		
		
		
		
	}
 
}
